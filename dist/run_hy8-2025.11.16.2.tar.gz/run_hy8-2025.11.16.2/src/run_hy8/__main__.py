"""Entry-point for `python -m run_hy8`."""

from .cli import main

if __name__ == "__main__":
    raise SystemExit(main())
